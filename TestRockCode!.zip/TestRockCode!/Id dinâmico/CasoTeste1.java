/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casosTesteIdDinamico;

import objectrepository.ObjectRepository;
import objectrepository.ObjectRepository.Interacao;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTeste1 {

    public static void run (){
                        
        System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");      

        //Usa o botão de pesquisa como ancora para clicar no botao estou com sorte        
        WebElement ancora = ObjectRepository.Google.searchButton(driver);
        Interacao.click(driver, ancora, 150, 0);
        
        driver.get("https://www.google.com.br");
        
        //Usa o botao estou com sorte como ancora para clicar e escrever no botão de pesquisa
        ancora = ObjectRepository.Google.estouComSorteButton(driver);
        Interacao.write(driver, ancora, -300, -70, "Selenium");
              
        //fechar browser
        driver.quit();
            
    }
    
}
