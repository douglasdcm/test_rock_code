/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casosTesteIdDinamico;


import java.awt.AWTException;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectrepository.ObjectRepository;
import objectrepository.ObjectRepository.Interacao;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTeste2 {

    public static void run () throws AWTException{
                        
        //System.setProperty("webdriver.firefox.marionette","C:\\Selenium\\geckodriver.exe");
        //FirefoxDriver driver = new FirefoxDriver();
        System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        //driver.manage().window().maximize();
        driver.get("https://www.google.com/");
        WebElement ancora;
        

        //Usa o botão de pesquisa como ancora para clicar no botao estou com sorte        
        ancora = ObjectRepository.Google.searchButton(driver);
        Interacao.click(driver, ancora, 150, 0);
        
        driver.get("https://www.google.com.br");
        
        //Usa o botao estou com sorte como ancora para clicar no botão de pesquisa
        ancora = ObjectRepository.Google.estouComSorteButton(driver);
        Interacao.write(driver, ancora, -300, -70, "Selenium");
        
        
        //driver.get("https://www.google.com.br");        
        //ObjectRepository.Google.searchBox(driver).sendKeys("QA");
        //ObjectRepository.Google.searchBox(driver).sendKeys(Keys.RETURN);
        //try {
        //    Thread.sleep(5000);
        //} catch (InterruptedException ex) {
        //    Logger.getLogger(CasoTeste1.class.getName()).log(Level.SEVERE, null, ex);
        //}

        //Usa a caixa de pesquisa e o link Notícias como ancoras para clicar no link Todas
        //WebElement ancoraHorizontal = ObjectRepository.Google.googleNews(driver);
        //WebElement ancoraVertical = ObjectRepository.Google.searchBox(driver);
        //WebElement todasLink = ObjectRepository.Google.todasLink(driver);
        //Point pt = todasLink.getLocation();
        //Point ph = ancoraHorizontal.getLocation();
        //Point pv = ancoraVertical.getLocation();
        //Interacao.click(driver, ancoraHorizontal, ancoraVertical, 'n', 100, 110);        
        //fechar browser
        //driver.quit();
            
    }
    
}
