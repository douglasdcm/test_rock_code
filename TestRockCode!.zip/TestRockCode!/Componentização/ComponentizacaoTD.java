/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package componentes;

import casos.teste.*;


/**
 *
 * @author TestRock!
 */
public class ComponentizacaoTD {
    public static void mainOLD (String args[]) throws InterruptedException{        
        
        //instacia o caso de teste
        AcessarMensagensEPesquisarVagas AcessarMensagensEPesquisarVagas = new AcessarMensagensEPesquisarVagas();
        
        //executa o caso de teste
        //AcessarMensagensEPesquisarVagas.run();
        AcessarMinhaRedeEPesquisarVagas.run();
        
        
    }
    
}
