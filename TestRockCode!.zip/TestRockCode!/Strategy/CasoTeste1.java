/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casostestestrategy;

import Strategy.Acao;
import componentesstrategy.*;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTeste1 {

    public static void run (){
            
            
        System.out.println("CasoTeste1 Início Status");
            
        System.setProperty("webdriver.firefox.marionette","C:\\Selenium\\geckodriver.exe");
        FirefoxDriver driver = new FirefoxDriver();
        driver.get("https://www.linkedin.com/");
        
        //cria a classe login e seta o email e senha
        Login login = new Login();
        login.setParametros("testrockchannel@gmail.com", "caneta");
        //Cria o componente Login e envia para a manipulação da Acao
        //login é do tipo Strategy
        Acao acao = new Acao(login);
        //Executa a acao de Login que neste contexo é "logar"
        System.out.println("Login " + acao.executar(driver));
        
        //Cria o compoente AcessarMinhaRede e envia para a manipulação da Acao 
        acao = new Acao(new AcessarMinhaRede());
        //Executa a acao de AcessarMinhaRede que neste contexo é "acessar"
        System.out.println("AcessarMinhaRede " + acao.executar(driver));
        
        acao = new Acao(new AcessarVagas());
        System.out.println("AcessarVagas " + acao.executar(driver)); 
        
        PesquisarVagas pesquisarVagas = new PesquisarVagas();
        pesquisarVagas.setParametros("Selenium", "Brasil");
        acao = new Acao(pesquisarVagas);
        System.out.println("PesquisarVagas " + acao.executar(driver));        

        //fechar browser
        driver.quit();
            
        System.out.println("CasoTeste1 Fim Status");
    }
    
}
