b = ( {canal: "TestRock!", link: "https://www.youtube.com/channel/UCaM9f-dK58sezfVmNIoAi6g", area: "Tecnologia"} )
b.each { |k, v| puts "#{k}: #{v}" } 