i = 0
a = [1, 2, 3, 4, 5, 6]
a.length.times do
	puts a[i]
	i = i+1 
end