require_relative "My_classe"

m = My_class.new
m.metodo("AHHHHH!!!!")