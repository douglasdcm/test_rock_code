/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package casosTesteBuilder;

import componentesBuilder.*;
import designBuilder.CasoTeste;
import designBuilder.CasoTesteBuilder;
import designBuilder.Componente;
import java.util.ArrayList;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTesteGenerator {
    private CasoTesteBuilder casoTesteBuilder;
       
    public CasoTesteGenerator(CasoTesteBuilder casoTesteBuilder) {
        super();//verificar necessidade
        //seta a variavel da superclasse como o construtor do caso de teste 1
        this.casoTesteBuilder = casoTesteBuilder;
    }
    public CasoTeste geraCasoTeste(){
        ArrayList<Componente> componenteList = new ArrayList<>();
        //cria o driver
        WebDriver driver = casoTesteBuilder.buildDriver("Firefox");
        //cria o login
        casoTesteBuilder.buildLogin(driver, "testrockchannel@gmail.com", "carneFraca");
        //cria lista de componentes
        componenteList.add(new AcessarMensagens(driver));
        componenteList.add(new EnviarMensagem(driver, "Conta Fake","Inscreva-se no canal TestRock! :)"));       
        casoTesteBuilder.buildComponenteList(driver, componenteList);
        casoTesteBuilder.buildLogout(driver);
        
        //cria o caso de teste 1 usando o getCasoTeste
        //getCasoTeste retorna uma instancia do CasoTeste que foi criado com os parametros this.driver e this.login
        CasoTeste casoTeste = casoTesteBuilder.getCasoTeste();
        return casoTeste;
    }

}
