/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package componentesBuilder;

//import designBuilder.Componente;
import designBuilder.Componente;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectrepository.ObjectRepository;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class AcessarMensagens implements Componente {
 
        private WebDriver driver;
        
        public AcessarMensagens (WebDriver driver) {
            this.driver = driver;
        }    
    
        @Override
        public void executar () {
            ObjectRepository.LinkedIn.Mensagens.iconeAcesso(this.driver).click();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(AcessarMensagens.class.getName()).log(Level.SEVERE, null, ex);
            }
        }    
}
