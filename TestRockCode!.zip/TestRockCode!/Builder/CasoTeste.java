/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package designBuilder;

import componentesBuilder.Login;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public interface CasoTeste {
    public void driver(WebDriver driver);
    public void login(WebDriver driver, String email, String senha);
    public void executar();
    public void logout(WebDriver driver);
}
