/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package designBuilder;

import java.util.ArrayList;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public interface CasoTesteBuilder {
    public WebDriver buildDriver (String browser);
    public void buildLogin (WebDriver driver, String email, String senha);
    public void buildComponenteList (WebDriver driver, ArrayList<Componente> componente);
    public void buildLogout (WebDriver driver);
    CasoTeste getCasoTeste();
}
