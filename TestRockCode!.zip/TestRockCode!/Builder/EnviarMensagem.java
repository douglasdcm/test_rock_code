/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package componentesBuilder;

//import designBuilder.Componente;
import designBuilder.Componente;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectrepository.ObjectRepository;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class EnviarMensagem implements Componente {
    
        private String conta;
        private String texto;
        private WebDriver driver;
    
    public EnviarMensagem (WebDriver driver, String conta, String texto) {
        this.conta = conta;
        this.texto = texto;
        this.driver = driver;
    }  
    
        //@Override
        public void executar () {            
            ObjectRepository.LinkedIn.Mensagens.novaMensagemButton(this.driver).click(); 
            ObjectRepository.LinkedIn.Mensagens.contaTextBox(driver).sendKeys(this.conta);
            try {
                Thread.sleep(7000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EnviarMensagem.class.getName()).log(Level.SEVERE, null, ex);
            }
            //ObjectRepository.LinkedIn.Mensagens.contaTextBox(driver).sendKeys(Keys.RETURN);
            ObjectRepository.LinkedIn.Mensagens.contaSearchList(driver).click();
            try {
                Thread.sleep(7000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EnviarMensagem.class.getName()).log(Level.SEVERE, null, ex);
            }
            ObjectRepository.LinkedIn.Mensagens.mensagemTextBox(driver).sendKeys(this.texto);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EnviarMensagem.class.getName()).log(Level.SEVERE, null, ex);
            }
            ObjectRepository.LinkedIn.Mensagens.enviarMensagemButton(this.driver).click();
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(EnviarMensagem.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
}
