/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package componentesBuilder;

import designBuilder.Componente;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectrepository.ObjectRepository;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class Login implements Componente {

    private String email;
    private String senha;
    private WebDriver driver;
    
    public Login (WebDriver driver, String email, String senha) {
        this.email = email;
        this.senha = senha;
        this.driver = driver;
    }
    
    @Override
    public void executar () {          
        ObjectRepository.LinkedIn.Login.emailBox(this.driver).sendKeys(this.email);
        ObjectRepository.LinkedIn.Login.passwordBox(this.driver).sendKeys(this.senha);
        ObjectRepository.LinkedIn.Login.loginButton(this.driver).click();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

