/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package casosTesteBuilder;

import componentesBuilder.*;
import designBuilder.CasoTeste;
import designBuilder.CasoTesteBuilder;
import designBuilder.Componente;
import java.util.ArrayList;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTesteImplementacaoBuilder implements CasoTesteBuilder {

    private WebDriver driver;
    private Login login;
    private Logout logout;
    private ArrayList<Componente> componenteList;
    
    @Override
    public WebDriver buildDriver(String browser) {
        DriverFactory driverFactory = new DriverFactory();
        WebDriver driver = driverFactory.setBrowser(browser);
        driver.get("https://www.linkedin.com/");
        this.driver = driver;
        return driver;
    }

    @Override
    public void buildLogin(WebDriver driver, String email, String senha) {
        Login login = new Login(driver, email, senha); 
        this.login = login;
    }

    @Override
    public CasoTeste getCasoTeste() {
        //return new CasoTeste1 ();
        return new CasoTesteImplementacao (driver, login, componenteList, logout);
    }

    @Override
    public void buildComponenteList(WebDriver driver, ArrayList<Componente> componenteList) {
        this.componenteList = componenteList;
    }

    @Override
    public void buildLogout(WebDriver driver) {
        Logout logout = new Logout(driver); 
        this.logout = logout;
    }

}
