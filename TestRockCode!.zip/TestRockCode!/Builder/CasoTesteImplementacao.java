/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package casosTesteBuilder;

import componentesBuilder.Login;
import componentesBuilder.Logout;
import designBuilder.CasoTeste;
import designBuilder.Componente;
import java.util.ArrayList;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTesteImplementacao implements CasoTeste {

    WebDriver driver;
    Login login;
    ArrayList<Componente> componenteList;
    Logout logout;
    
    public CasoTesteImplementacao(WebDriver driver, Login login, ArrayList<Componente> componenteList, Logout logout) {
        this.driver = driver;
        this.login = login;
        this.componenteList = componenteList;
        this.logout = logout;
    }    
    
    @Override
    public void driver(WebDriver driver) {
        this.driver = driver;
    }

    @Override
    public void login(WebDriver driver, String email, String senha) {
        this.login = login;
    }
    
    public void componenteList(Componente componente) {
        this.componenteList.add(componente);
    }
    
    public void executar (){
        login.executar();
        for (Componente componente : componenteList){
            componente.executar(); 
        }
        logout.executar();
    }

    @Override
    public void logout(WebDriver driver) {
        this.logout = logout;
    }

}
