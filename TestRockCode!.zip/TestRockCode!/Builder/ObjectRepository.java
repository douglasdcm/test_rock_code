/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectrepository;

import componentesFactory.Login;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author TestRock!
 */
public class ObjectRepository {
    
    public static class Interacao {
        
        public static void click(WebDriver driver, WebElement ancora, int offsetX, int offsetY){
            Actions builder = new Actions(driver); 
            builder.moveToElement(ancora, offsetX, offsetY).click().perform();
        }
    
        public static void write(WebDriver driver, WebElement ancora, int offsetX, int offsetY, String texto){
            Actions builder = new Actions(driver);
            builder.moveToElement(ancora, offsetX, offsetY).sendKeys(texto).perform();
        }
        
        //sobrecarga de método
        /**
        Descrição do método
        @param driver: objeto WebDriver
        @param ancoraHorizontal: objeto ancora horizontal 
        @param ancoraVertical: objeto ancora vertical
        @param acima: se o objeto procurado estiver acima do objeto horizontal, então setar o valor como 'n' ou 'N', senão setar como 's' ou 'S'
        @param erroH: é a precisão (fator de erro) sugerida pelo desenvolvedor na direção horizontal para encontrar o objeto
        @param erroV: é o precisão (fator de erro) sugerida pelo desenvolvedor na direção vertical para encontrar o objeto  
        */
        public static void click(WebDriver driver, WebElement ancoraHorizontal, WebElement ancoraVertical, char acima,int erroH, int erroV){
            int yh = ancoraHorizontal.getLocation().getY();
            int yv = ancoraVertical.getLocation().getY();
            int offsetY = yh - yv;
            if((acima == 'n') || (acima == 'N')){
                offsetY = yv - yh;
            }
            Interacao.click(driver, ancoraVertical, erroH, offsetY + erroV);
        }
    }
    
    public static class LinkedIn {
        
        public static class Login {
        
            public static WebElement emailBox (WebDriver driver) {
               WebElement element = null;
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.id("login-email"));
               return element;
            }

            public static WebElement passwordBox (WebDriver driver) {
               WebElement element = null;
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.id("login-password"));
               return element;
            }

            public static WebElement loginButton (WebDriver driver) {
               WebElement element = null;
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.id("login-submit"));
               return element;
            }

            public void setParametros(String string, String string0) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        }
                
        public static class MinhaRede {        
            public static WebElement iconeAcesso (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@id='mynetwork-nav-item']/a/span[2]"));
               return element;
            }
            
            public static WebElement conectarButton (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.cssSelector("button.mn-person-card__person-btn-ext.button-secondary-medium"));
               return element;
            }
            
            public static WebElement conectarButtonV2 (WebDriver driver, int i) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@class='mn-pymk-list Elevation-2dp ember-view']/ul/li[" + i + "]/div[2]/button[1]"));
               return element;
            }
            
            public static WebElement pessoasQueConhecaLabel (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@class='mn-pymk-list Elevation-2dp ember-view']/h3"));
               return element;
            }
        }
    
        public static class Vagas {
        
            public static WebElement iconeAcesso (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@id='jobs-nav-item']/a/span[2]"));
               return element;
            }
            
            public static WebElement caixaPesquisaCargo (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@placeholder='Pesquise vagas por cargo, palavra-chave ou empresa…']"));
               return element;
            }
            
            public static WebElement caixaPesquisaLocalidade (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@placeholder='Cidade, estado, código postal ou país']"));
               return element;
            }
            
            public static WebElement botaoPesquisar (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               //element = driver.findElement(By.cssSelector("button.submit-button"));
               element = ObjectRepository.LinkedIn.Vagas.caixaPesquisaLocalidade(driver);
               return element;
            }
            
        } 
    
        public static class Mensagens {
        
            public static WebElement iconeAcesso (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@id='messaging-nav-item']/a/span[2]"));
               return element;
            }
            
            public static WebElement novaMensagemButton (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.cssSelector("li-icon[type=\"compose-icon\"] > svg.artdeco-icon > g.large-icon > path"));
               return element;
            }
            
            public static WebElement mensagensLabel (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@class='msg-conversations-container__title Sans-17px-black-85%-semibold']"));
               return element;
            }
            
            public static WebElement contaTextBox (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@placeholder='Insira um ou mais nomes…']"));
               return element;
            }
            
            public static WebElement contaSearchList (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@class='msg-connections-lookup__search-results list-style-none']"));
               return element;
            }
            
            public static WebElement mensagemTextBox (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@placeholder='Escreva a mensagem ou anexe o arquivo']"));
               return element;
            }
            
            public static WebElement enviarMensagemButton (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.cssSelector("button.button-tertiary-medium.msg-compose-form__send-button"));
               return element;
            }
        }    
        
        public static class Logout {
        
            public static WebElement iconePerfil (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.id("id=nav-settings__dropdown-trigger"));
               return element;
            }
            
            public static WebElement iconeSair (WebDriver driver) {
               WebElement element = null;               
               // Escreva o código para achar o elemento aqui
               element = driver.findElement(By.xpath(".//*[@href='/logout/']"));
               return element;
            }
       }    
    }
    
    public static class Google {
        
        public static WebElement searchBox (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.id("lst-ib"));
           return element;            
        }
        
        public static WebElement searchButton (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.name("btnK"));
           return element;            
        }
        
        public static WebElement searchButton2 (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.id("lst-ib"));
           return element;            
        }
        
        public static WebElement googleLogo (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.id("logo"));
           return element;            
        }
        
        public static WebElement googleNews (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.xpath(".//*[@id='tsf']/div[2]"));
           return element;            
        }
        
        public static WebElement estouComSorteButton (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.name("btnI"));
           return element;            
        }
        
        public static WebElement todasLink (WebDriver driver) {           
           WebElement element = null;
           // Write Code to find element here
           element = driver.findElement(By.xpath(".//*[@id='hdtb-msb-vis']/div[1]"));
           return element;            
        }
                
    }
    
}
