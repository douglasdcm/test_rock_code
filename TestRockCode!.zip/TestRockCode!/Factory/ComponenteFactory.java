/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package designFactory;

import componentesFactory.*;
import linkedin.AdicionarAmigos;

/**
 *
 * @author TestRock!
 */
public class ComponenteFactory {
    
   //Recebe o Componente 
   public Componente getComponente(String componente){
      if(componente == null){
         return null;
      }		
      if(componente.equalsIgnoreCase("Login")){
         return new Login();
         
      } else if(componente.equalsIgnoreCase("AcessarMinhaRede")){
         return new AcessarMinhaRede();
         
      } else if(componente.equalsIgnoreCase("AcessarMensagens")){
         return new AcessarMensagens();
            
      } else if(componente.equalsIgnoreCase("AcessarVagas")){
         return new AcessarVagas();
            
      } else if(componente.equalsIgnoreCase("PesquisarVagas")){
         return new PesquisarVagas();
      } else if(componente.equalsIgnoreCase("AdicionarAmigos")){
         return new AdicionarAmigos();
      }      
      return null;
   }
   
}

