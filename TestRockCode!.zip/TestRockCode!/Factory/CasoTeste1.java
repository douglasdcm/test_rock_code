/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casosTesteFactory;

import componentesFactory.*;
import designFactory.Componente;
import designFactory.ComponenteFactory;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 *
 * @author TestRock!
 */
public class CasoTeste1 {

    public static void run (){
                        
        System.setProperty("webdriver.firefox.marionette","C:\\Selenium\\geckodriver.exe");
        FirefoxDriver driver = new FirefoxDriver();
        driver.get("https://www.linkedin.com/");
        
        //Cria a fábrica de componentes
        ComponenteFactory componenteFactory = new ComponenteFactory();

        //Cria o componente Login e loga no sistema
        Componente componente = componenteFactory.getComponente("Login");    
        ((Login)componente).setParametros("testrockchannel@gmail.com", "joelho");        
        ((Componente)componente).executar(driver); 
        
        componente = componenteFactory.getComponente("AcessarMinhaRede");
        componente.executar(driver);
        
        componente = componenteFactory.getComponente("AcessarVagas");
        componente.executar(driver);

        componente = componenteFactory.getComponente("PesquisarVagas");    
        ((PesquisarVagas)componente).setParametros("Selenium", "Brasil");
        ((Componente)componente).executar(driver);         

        //fechar browser
        driver.quit();
            
        System.out.println("CasoTeste1 Fim Status");
    }
    
}
