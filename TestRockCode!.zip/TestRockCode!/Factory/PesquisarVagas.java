/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package componentesFactory;

import designFactory.Componente;
import java.util.logging.Level;
import java.util.logging.Logger;
import objectrepository.ObjectRepository;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

/**
 *
 * @author TestRock!
 */
public class PesquisarVagas implements Componente {

        private String cargo;
        private String localidade;
    
        public void setParametros (String cargo, String localidade) {
            this.cargo = cargo;
            this.localidade = localidade;
        }    
    
        @Override
        public void executar (WebDriver driver) {
            //String status = "";            
            ObjectRepository.LinkedIn.Vagas.caixaPesquisaCargo(driver).sendKeys(this.cargo);            
            ObjectRepository.LinkedIn.Vagas.caixaPesquisaLocalidade(driver).sendKeys(this.localidade);
            ObjectRepository.LinkedIn.Vagas.botaoPesquisar(driver).sendKeys(Keys.RETURN);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(PesquisarVagas.class.getName()).log(Level.SEVERE, null, ex);
            }
            //status = "Passed";
            //return status;
        }
            
}
